﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    internal class Users
    {
        public string Name;
        public string Password;
        public string Role;


        public Users(string name, string password, string role)
        {
            Name = name;
            Password = password;
            Role = role;
        }
        public Users()
        {
            Name = "1";
            Password = "1234";
            Role = "admin";
        }

        public static List<Users> Loaddata()
        {
            string uDfile = "uDfile.txt";
            List<Users> loadedBooks = new List<Users>();

            using (StreamReader reader = new StreamReader(uDfile))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] userData = line.Split(',');
                    if (userData.Length == 3)
                    {
                        string name = userData[0];
                        string password = userData[1];
                        string role = (userData[2]);


                        loadedBooks.Add(new Users(name, password, role));
                    }
                }
            }
            Console.WriteLine("Books loaded from file successfully.");


            return loadedBooks;
        }



    }
}
