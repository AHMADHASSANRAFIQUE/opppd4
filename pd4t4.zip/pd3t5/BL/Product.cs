﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    internal class Product
    {
        public string Name;
        public int Price;
        public int Stock;
        public Product(string name, int price, int stock)
        {
            Name = name;
            Price = price;
            Stock = stock;
        }
        public Product()
        {
            Name = "Null";
            Price = 00;
            Stock = 00;
        }

        public static List<Product> LoaddataP()
        {            
            List<Product> loadedBooks = new List<Product>();
            if (File.Exists("pDfile.txt"))
            {
                using (StreamReader reader = new StreamReader("pDfile.txt"))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] userData = line.Split(',');
                        if (userData.Length == 3)
                        {
                            string name = userData[0];
                            int price = int.Parse(userData[1]);
                            int stock = (int.Parse(userData[2]));

                            loadedBooks.Add(new Product(name, price, stock));
                        }
                    }
                }
                Console.WriteLine("Product loaded from file successfully.");
            }

            return loadedBooks;
        }

    }
}
