﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using pd4p2;

namespace pd4p2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Stats> skillList = new List<Stats>();
            List<Player> playerList = new List<Player>();
            while (true)
            {
                string option = Menu();
                if (option == "1")
                {
                    Console.Clear();
                    Console.WriteLine("\tAdd Player");
                    Console.WriteLine("Player name: ");
                    string name = Console.ReadLine();
                    Console.WriteLine(" Health: ");
                    double health = double.Parse(Console.ReadLine());
                    Console.WriteLine(" Energy: ");
                    double energy = double.Parse(Console.ReadLine());
                    Console.WriteLine(" Armor: ");
                    double armor = double.Parse(Console.ReadLine());
                    Player p1 = new Player(name, health, energy, armor);
                    if (health <= p1.maxhealth && energy <= p1.maxenergy)
                    {
                        playerList.Add(p1);
                    }
                    else
                    {
                        Console.WriteLine("Max health or Energy is 100!.. ");
                    }                    
                }
                else if (option == "2")
                {
                    Console.Clear();
                    Console.WriteLine("\tAdd Skill");
                    Console.WriteLine("Skill name: ");
                    string name = Console.ReadLine();
                    Console.WriteLine(" damage: ");
                    double damage = double.Parse(Console.ReadLine());
                    Console.WriteLine(" Penetration: ");
                    double penet = double.Parse(Console.ReadLine());
                    Console.WriteLine(" Cost: ");
                    double cost = double.Parse(Console.ReadLine());
                    Console.WriteLine(" heal: ");
                    double heal = double.Parse(Console.ReadLine());
                    Console.WriteLine(" description (Don't use spaces!): ");
                    string desc = (Console.ReadLine());
                    Stats s1 = new Stats(name, damage, penet, cost, heal, desc);
                    skillList.Add(s1);
                }
                else if (option == "3")
                {
                    Console.Clear();
                    Console.WriteLine("Player Info.");
                    Console.WriteLine("Enter Name: ");
                    string name = Console.ReadLine();
                    for (int i = 0; i < playerList.Count; i++)
                    {
                        if (name == playerList[i].name)
                        {
                            Console.WriteLine(" Name: " + playerList[i].name);
                            Console.WriteLine(" Health: " + playerList[i].health);
                            Console.WriteLine(" Energy: " + playerList[i].energy);
                            Console.WriteLine(" Armor: " + playerList[i].armor);                            
                        }
                    }
                }
                else if(option == "4")
                {
                    
                    Console.Clear();
                    Console.WriteLine("Learn Skill");
                    Console.WriteLine("Player name: ");
                    string name = Console.ReadLine();
                    Console.WriteLine("Skill name: ");
                    string sname = Console.ReadLine();
                    if(Player.learnSkill(playerList, name, sname, skillList))
                    {
                        Console.WriteLine(" Skill Successfully Learned!..");
                    }
                    else
                    {
                        Console.WriteLine(" Invalid Skill Name or Player Name!..");
                    }                    
                }
                else if(option == "5")
                {
                    Console.WriteLine("\tAttack");
                    Console.WriteLine("Enter player name");
                    string aname = Console.ReadLine();
                    Console.WriteLine("Enter skill name");
                    string sname = Console.ReadLine();
                    Console.WriteLine("Enter target player name");
                    string target = Console.ReadLine();
                    string attack = Player.attack(aname, sname, playerList, skillList, target);
                    Console.WriteLine(attack);
                }
                Console.ReadKey();
            }
        }
        static string Menu()
        {
            Console.Clear();
            string option;
            Console.WriteLine("\tFight");
            Console.WriteLine("1.Add player");
            Console.WriteLine("2.Add Statistic");
            Console.WriteLine("3.Display player info.");
            Console.WriteLine("4.Learn Skill");
            Console.WriteLine("5.Attack");
            Console.WriteLine("6.Exit");
            option = Console.ReadLine();
            return option;
        }
    }
}
