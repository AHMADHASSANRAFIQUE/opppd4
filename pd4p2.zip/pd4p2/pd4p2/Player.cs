﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace pd4p2
{
    internal class Player
    {
        public string name;
        public double health;
        public double maxhealth = 100;
        public double armor;
        public double energy;
        public double maxenergy = 100;
        public Stats skillStat;
        public Player(string name, double health, double energy, double armor) 
        {
            this.name = name;
            this.health = health;
            this.energy = energy;
            this.armor = armor;
        }
        public static bool learnSkill(List<Player> playerList,string name, string sname, List<Stats> skillList)
        {
            bool check = false;
            bool check1 = false;
            bool check2 = false;
            int count = 0;
            for (int i = 0; i < playerList.Count; i++)
            {
                if (name == playerList[i].name)
                {
                    check = true;
                    count = i;
                    break;
                }
            }
            for (int i = 0; i < skillList.Count; i++)
            {
                if (sname == skillList[i].name)
                {
                    check1 = true;
                    if (check && check1)
                    {
                        playerList[count].skillStat = skillList[i];
                        check2 = true;
                    }
                    break;
                }
            }            
            return check2;
        }
        public static string attack(string aname, string sname, List<Player> playerList, List<Stats> skillList, string target)
        {
            bool check = false;
            bool check1 = false;            
            int count = 0, count1 = 0;

            for (int i = 0; i < playerList.Count; i++)
            {
                if (aname == playerList[i].name && sname == playerList[i].skillStat.name)
                {
                    check = true;
                    count = i;
                    break;
                }
            }
            for (int i = 0; i < playerList.Count; i++)
            {
                if (target == playerList[i].name)
                {
                    check1 = true;
                    count1 = i;
                    break;
                }
            }
            if (check && check1)
            {
                playerList[count1].armor = playerList[count1].armor - playerList[count].skillStat.penetration;
                if (playerList[count1].energy < playerList[count].skillStat.cost)
                {
                    return (playerList[count].name + " attempted to use" + playerList[count].skillStat.name + ", but didn't have enough energy!");
                }
                else
                {
                    playerList[count].energy -= playerList[count].skillStat.cost;
                    double finaldamage = ((playerList[count].skillStat.damage) * ((100 - (playerList[count1].armor)) / 100));
                    playerList[count1].health -= finaldamage;
                    if((playerList[count].health += playerList[count].skillStat.heal) < 100)
                    {
                        
                    }
                    else
                    {
                        playerList[count].health = 100;
                    }
                    return (playerList[count].name + " used " + playerList[count].skillStat.name + " ,"+ playerList[count].skillStat.description +", against "
                    + playerList[count1].name + ", doing " + finaldamage + " damage! " + playerList[count].name + " healed for " + playerList[count].skillStat.heal
                    + " health! " + playerList[count1].name + " is at " + playerList[count1].health + "% health.");                    
                }
            }
            else
            {
                return "Invalid player Name or Skill Name!..";
            }
        }
        /*Player alice = new Player("Alice", 110, 50, 10);
        Player bob = new Player("Bob", 100, 60, 20);

        Stats fireball = new Stats(“fireball”, 23, 1.2, 5, 15, "a firey magical attack");
        alice.learnSkill(fireball);
        Console.WriteLine(alice.attack(bob));
        
        Stats superbeam = new Stats(“superbeam”, 200, 50, 50, 75, "an overpowered attack, pls nerf")
        Console.WriteLine(bob.attack(alice))
        // Bob attempted to use superbeam, but didn't have enough energy!*/  
    }
}
