﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pd4p2
{
    internal class Stats
    {
        public string name;
        public double damage;        
        public double penetration;
        public double cost;
        public double heal;
        public string description;
        public Stats(string name, double damage, double penetration, double cost, double heal, string description) 
        {
            this.name = name;
            this.damage = damage;
            this.penetration = penetration;
            this.cost = cost;
            this.heal = heal;
            this.description = description;
        }
    }
}
