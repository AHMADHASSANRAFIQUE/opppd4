﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pd4p1
{
    internal class Program
    {
        static List<Ship> shipList = new List<Ship>();
        
        static void Main(string[] args)
        {            
            while (true)
            {
                Ship s1 = new Ship();
                Angle a1 = new Angle();
                Console.Clear();
                string option = Menu();
                if (option == "1")
                {
                    Console.Clear();
                    Console.WriteLine("Enter Ship Number");
                    s1.ShipNum = Console.ReadLine();
                    shipList.Add(s1);

                    Console.WriteLine("Enter Ship Latitude");
                    Console.WriteLine("Enter Latidude's degree");
                    a1.degree = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Latidude's min");
                    a1.min = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Latidude's Direction");
                    a1.direction = char.Parse(Console.ReadLine());
                    s1.angles.Add(a1);
                    Angle a2 = new Angle();

                    Console.WriteLine("Enter Ship Longitude");
                    Console.WriteLine("Enter Longitude's degree");
                    a2.degree = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Longitude's min");
                    a2.min = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Longitude's Direction");
                    a2.direction = char.Parse(Console.ReadLine());
                    s1.angles.Add(a2);
                    s1.count = s1.count + 2;
                    shipList.Add(s1);
                }
                else if (option == "2")
                {
                    Console.Clear();
                    Console.WriteLine("Enter Ship Number");
                    string sNum = Console.ReadLine();                    
                    if(Ship.checkSNum(shipList, sNum) == -1)
                    {
                        Console.WriteLine("Invalid Ship Num");
                    }
                    else
                    {
                        int x = Ship.checkSNum(shipList, sNum);
                        Console.WriteLine("Ship is at " + shipList[x].angles[shipList[x].count - 1].degree + "\u00b0" + shipList[x].angles[shipList[x].count - 1].min + "'" + shipList[x].angles[shipList[x].count - 1].direction
                        + " and " + shipList[x].angles[shipList[x].count].degree + "\u00b0" + shipList[x].angles[shipList[x].count].min + "'" + shipList[x].angles[shipList[x].count].direction);                        
                    }
                }
                else if (option == "3")
                {
                    Console.Clear();
                    Console.WriteLine("Enter latitude degree");
                    int latd = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter latitude min");
                    float latmin = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter latitude direction");
                    char latDi = char.Parse(Console.ReadLine());

                    Console.WriteLine("Enter longitude degree");
                    int lod = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter longitude min");
                    float lomin = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter longitude direction");
                    char loDi = char.Parse(Console.ReadLine());
                    if (Ship.checkDi(shipList, latd, latmin, latDi, lod, lomin, loDi) == -1)
                    {
                        Console.WriteLine("Invalid Ship Location");
                    }
                    else
                    {
                        int num = Ship.checkDi(shipList, latd, latmin, latDi, lod, lomin, loDi);
                        Console.WriteLine("Ship num is: " + shipList[num].ShipNum);
                    }
                }
                else if (option == "4")
                {
                    Console.Clear();
                    Console.WriteLine("Enter Ship’s serial number whose position you want to change: ");
                    string snum = Console.ReadLine();
                    for (int i = 0; i < shipList.Count; i++)
                    {
                        if (snum == shipList[i].ShipNum)
                        {
                            Console.WriteLine("Enter Ship Latitude");
                            Console.WriteLine("Enter Latidude's degree");
                            shipList[i].angles[shipList[i].count-1].degree = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Latidude's min");
                            shipList[i].angles[shipList[i].count - 1].min = float.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Latidude's Direction");
                            shipList[i].angles[shipList[i].count - 1].direction = char.Parse(Console.ReadLine());                                                        

                            Console.WriteLine("Enter Ship Longitude");
                            Console.WriteLine("Enter Longitude's degree");
                            shipList[i].angles[shipList[i].count].degree = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Longitude's min");
                            shipList[i].angles[shipList[i].count].min = float.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Longitude's Direction");
                            shipList[i].angles[shipList[i].count].direction = char.Parse(Console.ReadLine());

                            Console.WriteLine("Ship direction successfully change");
                            break;
                        }
                    }
                    Console.ReadKey();
                }
            }
        }
        static string Menu() 
        {
            string option;
            Console.WriteLine("\t\tOcean Navigation");
            Console.WriteLine("\tSelect one of the following");
            Console.WriteLine("\t1.Add Ship");
            Console.WriteLine("\t2.View Ship Position");
            Console.WriteLine("\t3.View ship serial Num");
            Console.WriteLine("\t4.Change Ship Position");
            option = Console.ReadLine();
            return option;
        }
    }
}
