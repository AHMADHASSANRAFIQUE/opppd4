﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pd4p1
{
    internal class Ship
    {
        public string ShipNum;
        public int count = -1;
        public List<Angle> angles = new List<Angle>();
        public string lat;
        public string lon;
        public static int checkSNum(List<Ship> shipList,string sNum)
        {
            int check = -1;
            for (int x = 0; x < shipList.Count; x++)
            {
                if (sNum == shipList[x].ShipNum)
                {
                    check = x;                    
                    break;
                }
            }
            return check;
        }
        public static int checkDi(List<Ship> shipList, int latd, float latmin, char latDi, int lod, float lomin, char loDi)
        {
            int check = -1;
            for (int i = 0; i < shipList.Count; i++)
            {                
                if (latd == shipList[i].angles[shipList[i].count - 1].degree && latmin == shipList[i].angles[shipList[i].count - 1].min && latDi == shipList[i].angles[shipList[i].count - 1].direction
                    && lod == shipList[i].angles[shipList[i].count].degree && lomin == shipList[i].angles[shipList[i].count].min && loDi == shipList[i].angles[shipList[i].count].direction)
                {
                    check = i;                
                    break;
                }
            }
            return check;
        }
    }
}
