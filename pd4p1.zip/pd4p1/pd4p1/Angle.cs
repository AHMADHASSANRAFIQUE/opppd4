﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pd4p1
{
    internal class Angle
    {
        public int degree;
        public float min;
        public char direction;   
    }
}
